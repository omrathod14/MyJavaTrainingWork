package com.aurionpro.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerSummary {
    private Long id;
    private String firstName;
    private String lastName;
    private String role; 
    private Boolean isCustomerActive;
}	
