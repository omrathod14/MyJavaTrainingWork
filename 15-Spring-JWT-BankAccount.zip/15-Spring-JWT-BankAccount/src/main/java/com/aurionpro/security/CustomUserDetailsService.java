package com.aurionpro.security;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.aurionpro.entity.Role;
import com.aurionpro.entity.User;
import com.aurionpro.repository.UserRepo;



@Service
public class CustomUserDetailsService implements UserDetailsService{
	
	@Autowired
	private UserRepo userRepo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user=userRepo.findByUsername(username).orElseThrow(
				()-> new UsernameNotFoundException("user not found"));
		
//		Set<GrantedAuthority> authorities = user
//			       .getRoles()
//			       .stream()
//			       .map((role) -> new SimpleGrantedAuthority(role.getRolename())).collect(Collectors.toSet());
		
		Role role=user.getRole();
		
		Set<GrantedAuthority> authorities = new HashSet<>();
	    SimpleGrantedAuthority authority=	new SimpleGrantedAuthority(role.getRolename());
		authorities.add(authority);

			return new org.springframework.security.core.userdetails.User(user.getUsername(),
			       user.getPassword(),
			       authorities);
                
	}
	
	

}
